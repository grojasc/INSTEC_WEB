import { HeaderItem } from "@/types/menu";

export const headerData: HeaderItem[] = [
  // Navigation labels updated to reflect the new site structure
  { label: "Inicio", href: "/#main-banner" },
  { label: "Proceso", href: "/#development" },
  { label: "Servicios", href: "/#work" },
  { label: "Experiencia", href: "/#portfolio" },
  { label: "Beneficios", href: "/#upgrade" },
  { label: "Contacto", href: "/#work" },
];
